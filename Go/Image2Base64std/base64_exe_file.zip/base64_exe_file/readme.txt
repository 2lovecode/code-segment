1.How to start
a.run the exe file : base64.exe
b.file->open to open a file
c.the base64 string will display in the box, you can use Ctrl+a to select all content

2.Operating environment
win7 64bit is ok
maybe win10 is ok too,you can test it

3.Notice
a.the file type must be (*.emf;*.bmp;*.exif;*.gif;*.jpeg;*.jpg;*.png;*.tiff)
b.if the file is over 500KB,it will be slow to get the base64 string,so please waiting for a moment